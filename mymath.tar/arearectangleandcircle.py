
import math as M  

def area_rectangle(length,width):
    return length * width


def area_circle (radius):
    return M.pi *(radius * radius)
