#/Creating a Python Pakcage
#/Create first and second Module (basic and stats.py file)
#Then create a __init__.py file
#Then goto Open a Terminal
#At the terminal type python3 to invoke python interpreter.
#Once the python interpreter is loaded.
#At the python prompt type import mymath
#If the above command runs without errors, it is an indication that the mymath package is successfully loaded.
#At the python prompt type mymath.basic.add(3,4)
#You should see an output 7 on the screen.
#At the python prompt type mymath.stats.mean([3,4,5])
#You should see an output 4.0 on the screen.
#Type exit() to quit python interpreter.